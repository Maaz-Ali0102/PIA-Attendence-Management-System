﻿namespace Attendence_Managment_system.Models
{
    public class Shift
    {
        public int Id { get; set; }
        public string ShiftName { get; set; }
        public TimeSpan WindowStartTime { get; set; }
        public TimeSpan LateTime { get; set; }
        public TimeSpan AutoAbsentTime { get; set; }

        public bool IsWithinWindow(TimeSpan now)
        {
            if (WindowStartTime < AutoAbsentTime)
            {
                return now >= WindowStartTime && now < AutoAbsentTime;
            }
            else
            {
                return now >= WindowStartTime || now < AutoAbsentTime;
            }
        }

        public bool IsLate(TimeSpan now)
        {
            if (WindowStartTime < AutoAbsentTime)
            {
                return now > LateTime;
            }
            else
            {
                if (now >= WindowStartTime) return now > LateTime;
                return true;
            }
        }

        public bool IsOvernight => AutoAbsentTime <= WindowStartTime;

        public DateTime GetShiftEndDateTime(DateTime shiftDay)
        {
            return IsOvernight ? shiftDay.AddDays(1).Add(AutoAbsentTime) : shiftDay.Add(AutoAbsentTime);
        }
    }
}