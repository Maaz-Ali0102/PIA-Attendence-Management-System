﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Attendence_Managment_system.Models
{
    [Table("SalaryHistory")]
    public class SalaryHistory
    {
        public int Id { get; set; }
        public int EmployeeId { get; set; }
        public decimal BaseSalary { get; set; }
        public decimal OvertimeRatePerHour { get; set; }
        public DateTime EffectiveFrom { get; set; }
        public DateTime? EffectiveTo { get; set; }

        public Employee? Employee { get; set; }
    }
}