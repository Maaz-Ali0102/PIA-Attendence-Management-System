﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Attendence_Managment_system.Models
{
    [Table("PayrollRecord")]
    public class PayrollRecord
    {
        public int Id { get; set; }
        public int EmployeeId { get; set; }
        public int Month { get; set; }
        public int Year { get; set; }
        public decimal BaseSalary { get; set; }
        public decimal TotalOvertimeHours { get; set; }
        public decimal OvertimePay { get; set; }
        public decimal NetAmount { get; set; }
        public DateTime GeneratedOn { get; set; }

        public Employee? Employee { get; set; }
    }
}