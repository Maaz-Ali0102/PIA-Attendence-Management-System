﻿namespace Attendence_Managment_system.Models
{
    public class Employee
    {
        public int Id { get; set; }
        public string EmpName { get; set; }
        public string Email { get; set; }
        public string PasswordHash { get; set; }
        public string Role { get; set; }
        public int DepartmentId { get; set; }
        public int? ShiftId { get; set; }
        public bool MustChangePassword { get; set; } = true;

        public Department? Department { get; set; }
        public Shift? Shift { get; set; }
        public ICollection<Attendance>? Attendances { get; set; }
    }
}