﻿namespace Attendence_Managment_system.Models
{
    public enum AttendanceStatus { Absent = 0, Present = 1, Leave = 2, WorkFromHome = 3, HalfDay = 4, InOffice = 5, Late = 6 }
    public class Attendance
    {
        public int Id { get; set; }
        public int EmployeeId { get; set; }
        public DateTime AttendanceDate { get; set; }
        public DateTime? EntryTime { get; set; }
        public DateTime? ExitTime { get; set; }
        public AttendanceStatus Status { get; set; }

        public Employee? Employee { get; set; }
    }
}
