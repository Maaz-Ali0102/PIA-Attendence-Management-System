﻿namespace Attendence_Managment_system.Models
{
    public class Department
    {
        public int Id { get; set; }
        public string DepartName { get; set; }
        public ICollection<Employee>? Employees { get; set; }
    }
}
