﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Attendence_Managment_system.Models
{
    public enum OvertimeStatus { Pending = 0, Approved = 1, Rejected = 2 }

    [Table("OvertimeRequest")]
    public class OvertimeRequest
    {
        public int Id { get; set; }
        public int AttendanceId { get; set; }
        public int EmployeeId { get; set; }
        public decimal OvertimeHours { get; set; }
        public OvertimeStatus Status { get; set; }
        public int? ReviewedBy { get; set; }
        public DateTime? ReviewedDate { get; set; }
        public DateTime CreatedDate { get; set; }

        public Employee? Employee { get; set; }
        public Attendance? Attendance { get; set; }
    }
}