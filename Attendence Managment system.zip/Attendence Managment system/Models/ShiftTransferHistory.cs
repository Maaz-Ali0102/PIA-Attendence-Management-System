﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Attendence_Managment_system.Models
{
    [Table("ShiftTransferHistory")]
    public class ShiftTransferHistory
    {
        public int Id { get; set; }
        public int EmployeeId { get; set; }
        public int? OldShiftId { get; set; }
        public int NewShiftId { get; set; }
        public DateTime TransferDate { get; set; }
    }
}