﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Attendence_Managment_system.Models
{
    [Table("DepartmentTransferHistory")]
    public class DepartmentTransferHistory
    {
        public int Id { get; set; }
        public int EmployeeId { get; set; }
        public int? OldDepartmentId { get; set; }
        public int NewDepartmentId { get; set; }
        public DateTime TransferDate { get; set; }
    }
}