﻿using Microsoft.EntityFrameworkCore;
using Attendence_Managment_system.Models;

namespace Attendence_Managment_system.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<Department> Departments { get; set; }
        public DbSet<Employee> Employees { get; set; }
        public DbSet<Attendance> Attendances { get; set; }
        public DbSet<Shift> Shifts { get; set; }
        public DbSet<DepartmentTransferHistory> DepartmentTransferHistories { get; set; }
        public DbSet<ShiftTransferHistory> ShiftTransferHistories { get; set; }
        public DbSet<SalaryHistory> SalaryHistories { get; set; }
        public DbSet<OvertimeRequest> OvertimeRequests { get; set; }
        public DbSet<PayrollRecord> PayrollRecords { get; set; }
    }
}