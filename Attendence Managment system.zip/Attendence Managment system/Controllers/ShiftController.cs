﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Attendence_Managment_system.Data;

namespace Attendence_Managment_system.Controllers
{
    [Authorize(Roles = "Admin")]
    public class ShiftController : Controller
    {
        private readonly AppDbContext _context;

        public ShiftController(AppDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var shifts = _context.Shifts.ToList();
            return View(shifts);
        }

        [HttpPost]
        public IActionResult UpdateShift(int id, TimeSpan windowStartTime, TimeSpan lateTime, TimeSpan autoAbsentTime)
        {
            var shift = _context.Shifts.Find(id);
            if (shift != null)
            {
                shift.WindowStartTime = windowStartTime;
                shift.LateTime = lateTime;
                shift.AutoAbsentTime = autoAbsentTime;
                _context.SaveChanges();
            }

            return RedirectToAction("Index");
        }
    }
}