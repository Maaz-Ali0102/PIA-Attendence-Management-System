﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Attendence_Managment_system.Data;
using Attendence_Managment_system.Models;
using Microsoft.EntityFrameworkCore;

namespace Attendence_Managment_system.Controllers
{
    [Authorize(Roles = "Admin")]
    public class AdminController : Controller
    {
        private readonly AppDbContext _context;

        public AdminController(AppDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var employees = _context.Employees
                .Include(e => e.Department)
                .Include(e => e.Shift)
                .ToList();
            return View(employees);
        }

        [HttpGet]
        public IActionResult AddEmployee()
        {
            ViewBag.Departments = _context.Departments.ToList();
            ViewBag.Shifts = _context.Shifts.ToList();
            return View();
        }

        [HttpPost]
        public IActionResult AddEmployee(string empName, string email, string tempPassword, int departmentId, int shiftId, string role)
        {
            if (_context.Employees.Any(e => e.Email == email))
            {
                ViewBag.Error = "Email already exists";
                ViewBag.Departments = _context.Departments.ToList();
                ViewBag.Shifts = _context.Shifts.ToList();
                return View();
            }

            var employee = new Employee
            {
                EmpName = empName,
                Email = email,
                Role = role,
                DepartmentId = departmentId,
                ShiftId = shiftId,
                MustChangePassword = true
            };

            var hasher = new PasswordHasher<Employee>();
            employee.PasswordHash = hasher.HashPassword(employee, tempPassword);

            _context.Employees.Add(employee);
            _context.SaveChanges();

            _context.DepartmentTransferHistories.Add(new DepartmentTransferHistory
            {
                EmployeeId = employee.Id,
                OldDepartmentId = null,
                NewDepartmentId = departmentId,
                TransferDate = DateTime.Now
            });

            _context.ShiftTransferHistories.Add(new ShiftTransferHistory
            {
                EmployeeId = employee.Id,
                OldShiftId = null,
                NewShiftId = shiftId,
                TransferDate = DateTime.Now
            });

            _context.SaveChanges();

            return RedirectToAction("Index");
        }

        [HttpGet]
        public IActionResult SetSalary(int id)
        {
            var employee = _context.Employees.Find(id);
            var currentSalary = _context.SalaryHistories
                .FirstOrDefault(s => s.EmployeeId == id && s.EffectiveTo == null);

            ViewBag.Employee = employee;
            return View(currentSalary);
        }

        [HttpPost]
        public IActionResult SetSalary(int id, decimal baseSalary, decimal overtimeRate)
        {
            var existing = _context.SalaryHistories
                .FirstOrDefault(s => s.EmployeeId == id && s.EffectiveTo == null);

            if (existing != null)
            {
                existing.EffectiveTo = DateTime.Today.AddDays(-1);
            }

            _context.SalaryHistories.Add(new SalaryHistory
            {
                EmployeeId = id,
                BaseSalary = baseSalary,
                OvertimeRatePerHour = overtimeRate,
                EffectiveFrom = DateTime.Today,
                EffectiveTo = null
            });

            _context.SaveChanges();
            return RedirectToAction("Index");
        }

        [HttpPost]
        public IActionResult RemoveEmployee(int id)
        {
            var employee = _context.Employees.Find(id);

            if (employee != null && employee.Role != "Admin")
            {
                bool hasAttendance = _context.Attendances.Any(a => a.EmployeeId == id);

                if (hasAttendance)
                {
                    TempData["Error"] = "Cannot remove employee with existing attendance records.";
                    return RedirectToAction("Index");
                }

                _context.Employees.Remove(employee);
                _context.SaveChanges();
            }

            return RedirectToAction("Index");
        }

        [HttpGet]
        public IActionResult TransferEmployee(int id)
        {
            var employee = _context.Employees
                .Include(e => e.Department)
                .Include(e => e.Shift)
                .FirstOrDefault(e => e.Id == id);

            ViewBag.Departments = _context.Departments.ToList();
            ViewBag.Shifts = _context.Shifts.ToList();
            return View(employee);
        }

        [HttpPost]
        public IActionResult TransferEmployee(int id, int newDepartmentId, int newShiftId)
        {
            var employee = _context.Employees.Find(id);
            if (employee != null && employee.Role != "Admin")
            {
                if (employee.DepartmentId != newDepartmentId)
                {
                    _context.DepartmentTransferHistories.Add(new DepartmentTransferHistory
                    {
                        EmployeeId = employee.Id,
                        OldDepartmentId = employee.DepartmentId,
                        NewDepartmentId = newDepartmentId,
                        TransferDate = DateTime.Now
                    });
                    employee.DepartmentId = newDepartmentId;
                }

                if (employee.ShiftId != newShiftId)
                {
                    _context.ShiftTransferHistories.Add(new ShiftTransferHistory
                    {
                        EmployeeId = employee.Id,
                        OldShiftId = employee.ShiftId,
                        NewShiftId = newShiftId,
                        TransferDate = DateTime.Now
                    });
                    employee.ShiftId = newShiftId;
                }

                _context.SaveChanges();
            }
            return RedirectToAction("Index");
        }
    }
}