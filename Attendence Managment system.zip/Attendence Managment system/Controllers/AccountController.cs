﻿using Attendence_Managment_system.Data;
using Attendence_Managment_system.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace Attendence_Managment_system.Models
{
    public class AccountController : Controller
    {
        private readonly AppDbContext _context;

        public AccountController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Login(string email, string password)
        {
            var employee = _context.Employees.FirstOrDefault(e => e.Email == email);

            if (employee == null)
            {
                ViewBag.Error = "Invalid email or password";
                return View();
            }

            var hasher = new PasswordHasher<Employee>();
            var result = hasher.VerifyHashedPassword(employee, employee.PasswordHash, password);

            if (result == PasswordVerificationResult.Failed)
            {
                ViewBag.Error = "Invalid email or password";
                return View();
            }

            // Claims banao — ye future mein department restriction ke liye use honge
            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.NameIdentifier, employee.Id.ToString()),
                new Claim(ClaimTypes.Name, employee.EmpName),
                new Claim(ClaimTypes.Email, employee.Email),
                new Claim("DepartmentId", employee.DepartmentId.ToString()),
                new Claim(ClaimTypes.Role, employee.Role)
            };

            var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
            var principal = new ClaimsPrincipal(identity);

            await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);

            if (employee.MustChangePassword)
            {
                return RedirectToAction("ChangePassword");
            }

            return RedirectToAction("Index", "Home");
        }

        [Authorize]
        [HttpGet]
        public IActionResult ChangePassword()
        {
            return View();
        }

        [Authorize]
        [HttpPost]
        public IActionResult ChangePassword(string currentPassword, string newPassword)
        {
            var empId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier).Value);
            var employee = _context.Employees.First(e => e.Id == empId);

            var hasher = new PasswordHasher<Employee>();
            var result = hasher.VerifyHashedPassword(employee, employee.PasswordHash, currentPassword);

            if (result == PasswordVerificationResult.Failed)
            {
                ViewBag.Error = "Current password is incorrect";
                return View();
            }

            employee.PasswordHash = hasher.HashPassword(employee, newPassword);
            employee.MustChangePassword = false;   // ab flag hata do
            _context.SaveChanges();

            ViewBag.Success = "Password changed successfully";
            return View();
        }

        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("Login");
        }

        public IActionResult AccessDenied()
        {
            return View();
        }
    }
}