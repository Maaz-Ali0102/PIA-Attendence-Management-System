﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Attendence_Managment_system.Data;
using Attendence_Managment_system.Models;

namespace Attendence_Managment_system.Controllers
{
    [Authorize(Roles = "Admin")]
    public class DepartmentController : Controller
    {
        private readonly AppDbContext _context;

        public DepartmentController(AppDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var departments = _context.Departments.ToList();
            return View(departments);
        }

        [HttpGet]
        public IActionResult AddDepartment()
        {
            return View();
        }

        [HttpPost]
        public IActionResult AddDepartment(string departName)
        {
            if (_context.Departments.Any(d => d.DepartName == departName))
            {
                ViewBag.Error = "Department already exists";
                return View();
            }

            _context.Departments.Add(new Department { DepartName = departName });
            _context.SaveChanges();

            return RedirectToAction("Index");
        }

        [HttpPost]
        public IActionResult RemoveDepartment(int id)
        {
            var hasEmployees = _context.Employees.Any(e => e.DepartmentId == id);

            if (hasEmployees)
            {
                TempData["Error"] = "Cannot remove department with existing employees. Transfer them first.";
                return RedirectToAction("Index");
            }

            var department = _context.Departments.Find(id);
            if (department != null)
            {
                _context.Departments.Remove(department);
                _context.SaveChanges();
            }

            return RedirectToAction("Index");
        }
    }
}