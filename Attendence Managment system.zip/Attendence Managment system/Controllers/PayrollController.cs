﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Attendence_Managment_system.Data;
using Attendence_Managment_system.Models;

namespace Attendence_Managment_system.Controllers
{
    [Authorize(Roles = "Admin")]
    public class PayrollController : Controller
    {
        private readonly AppDbContext _context;

        public PayrollController(AppDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var records = _context.PayrollRecords
                .Include(p => p.Employee)
                .OrderByDescending(p => p.Year).ThenByDescending(p => p.Month)
                .ToList();
            return View(records);
        }

        [HttpPost]
        public IActionResult Generate(int month, int year)
        {
            var employees = _context.Employees.Where(e => e.Role != "Admin").ToList();
            var periodStart = new DateTime(year, month, 1);
            var periodEnd = periodStart.AddMonths(1).AddDays(-1);

            foreach (var emp in employees)
            {
                bool alreadyGenerated = _context.PayrollRecords
                    .Any(p => p.EmployeeId == emp.Id && p.Month == month && p.Year == year);

                if (alreadyGenerated) continue;

                var salary = _context.SalaryHistories
                    .Where(s => s.EmployeeId == emp.Id && s.EffectiveFrom <= periodEnd
                        && (s.EffectiveTo == null || s.EffectiveTo >= periodStart))
                    .OrderByDescending(s => s.EffectiveFrom)
                    .FirstOrDefault();

                if (salary == null) continue;

                var approvedOvertime = _context.OvertimeRequests
                    .Include(o => o.Attendance)
                    .Where(o => o.EmployeeId == emp.Id
                        && o.Status == OvertimeStatus.Approved
                        && o.Attendance.AttendanceDate >= periodStart
                        && o.Attendance.AttendanceDate <= periodEnd)
                    .ToList();

                decimal totalOtHours = approvedOvertime.Sum(o => o.OvertimeHours);
                decimal otPay = totalOtHours * salary.OvertimeRatePerHour;

                _context.PayrollRecords.Add(new PayrollRecord
                {
                    EmployeeId = emp.Id,
                    Month = month,
                    Year = year,
                    BaseSalary = salary.BaseSalary,
                    TotalOvertimeHours = totalOtHours,
                    OvertimePay = otPay,
                    NetAmount = salary.BaseSalary + otPay,
                    GeneratedOn = DateTime.Now
                });
            }

            _context.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}