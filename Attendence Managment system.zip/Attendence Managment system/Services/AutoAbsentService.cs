﻿using Attendence_Managment_system.Data;
using Attendence_Managment_system.Models;
using Microsoft.EntityFrameworkCore;

namespace Attendence_Managment_system.Services
{
    public class AutoAbsentService : BackgroundService
    {
        private readonly IServiceProvider _serviceProvider;

        public AutoAbsentService(IServiceProvider serviceProvider)
        {
            _serviceProvider = serviceProvider;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                using (var scope = _serviceProvider.CreateScope())
                {
                    var context = scope.ServiceProvider.GetRequiredService<AppDbContext>();
                    var now = DateTime.Now;
                    var today = DateTime.Today;

                    var employeesWithShifts = context.Employees
                        .Where(e => e.ShiftId != null)
                        .ToList();

                    foreach (var emp in employeesWithShifts)
                    {
                        var shift = context.Shifts.Find(emp.ShiftId);
                        if (shift == null) continue;

                        bool overnight = shift.AutoAbsentTime <= shift.WindowStartTime;

                        // Aaj shuru hui shift ka deadline check karo
                        CheckAndMarkAbsent(context, emp, shift, today, now, overnight);

                        // Overnight shift ho to KAL shuru hui shift ka bhi deadline check karo
                        // (kyunki uska deadline aaj subah tak hai)
                        if (overnight)
                        {
                            CheckAndMarkAbsent(context, emp, shift, today.AddDays(-1), now, overnight);
                        }
                    }

                    context.SaveChanges();
                }

                await Task.Delay(TimeSpan.FromMinutes(5), stoppingToken);
            }
        }

        private void CheckAndMarkAbsent(AppDbContext context, Employee emp, Shift shift, DateTime shiftDay, DateTime now, bool overnight)
        {
            var shiftStart = shiftDay.Add(shift.WindowStartTime);
            var deadline = overnight
                ? shiftDay.AddDays(1).Add(shift.AutoAbsentTime)
                : shiftDay.Add(shift.AutoAbsentTime);

            // Shift shuru bhi honi chahiye thi, aur deadline bhi paar honi chahiye
            if (now < shiftStart || now < deadline)
            {
                return;
            }

            bool hasRecord = context.Attendances
                .Any(a => a.EmployeeId == emp.Id && a.AttendanceDate == shiftDay);

            if (!hasRecord)
            {
                context.Attendances.Add(new Attendance
                {
                    EmployeeId = emp.Id,
                    AttendanceDate = shiftDay,
                    Status = AttendanceStatus.Absent
                });
            }
        }
    }
}