﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using Attendence_Managment_system.Data;
using Attendence_Managment_system.Models;

namespace Attendence_Managment_system.Controllers
{
    [Authorize]
    public class OvertimeController : Controller
    {
        private readonly AppDbContext _context;

        public OvertimeController(AppDbContext context)
        {
            _context = context;
        }

        [Authorize(Roles = "Manager")]
        public IActionResult Index()
        {
            var empId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier).Value);
            var manager = _context.Employees.Find(empId);

            var requests = _context.OvertimeRequests
                .Include(o => o.Employee)
                .Include(o => o.Attendance)
                .Where(o => o.Status == OvertimeStatus.Pending && o.Employee.DepartmentId == manager.DepartmentId)
                .OrderBy(o => o.CreatedDate)
                .ToList();

            return View(requests);
        }

        [Authorize(Roles = "Manager")]
        [HttpPost]
        public IActionResult Review(int id, string decision)
        {
            var request = _context.OvertimeRequests.Find(id);
            var reviewerId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier).Value);

            if (request != null && request.Status == OvertimeStatus.Pending)
            {
                request.Status = decision == "approve" ? OvertimeStatus.Approved : OvertimeStatus.Rejected;
                request.ReviewedBy = reviewerId;
                request.ReviewedDate = DateTime.Now;
                _context.SaveChanges();
            }

            return RedirectToAction("Index");
        }

        public IActionResult MyRequests()
        {
            var empId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier).Value);

            var requests = _context.OvertimeRequests
                .Include(o => o.Attendance)
                .Where(o => o.EmployeeId == empId)
                .OrderByDescending(o => o.CreatedDate)
                .ToList();

            return View(requests);
        }
    }
}