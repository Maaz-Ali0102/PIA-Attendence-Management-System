﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using Attendence_Managment_system.Data;
using Attendence_Managment_system.Models;

namespace Attendence_Managment_system.Controllers
{
    [Authorize]
    public class PayrollController : Controller
    {
        private readonly AppDbContext _context;

        public PayrollController(AppDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            if (User.IsInRole("Admin")) return RedirectToAction("AdminDashboard");
            if (User.IsInRole("Manager")) return RedirectToAction("ManagerDashboard");
            return RedirectToAction("MyPayroll");
        }

        [Authorize(Roles = "Admin")]
        public IActionResult AdminDashboard(int? departmentId)
        {
            var query = _context.Employees
                .Include(e => e.Department)
                .Where(e => e.Role != "Admin")
                .AsQueryable();

            if (departmentId.HasValue)
            {
                query = query.Where(e => e.DepartmentId == departmentId.Value);
            }

            ViewBag.Departments = _context.Departments.ToList();
            ViewBag.SelectedDepartment = departmentId;

            return View(query.OrderBy(e => e.EmpName).ToList());
        }

        [Authorize(Roles = "Admin")]
        [HttpPost]
        public IActionResult GenerateManagers(int month, int year)
        {
            var managers = _context.Employees.Where(e => e.Role == "Manager").ToList();
            GeneratePayrollFor(managers, month, year);
            return RedirectToAction("AdminDashboard");
        }

        [Authorize(Roles = "Manager")]
        public IActionResult ManagerDashboard()
        {
            return View();
        }

        [Authorize(Roles = "Manager")]
        [HttpPost]
        public IActionResult Generate(int month, int year)
        {
            var empId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier).Value);
            var manager = _context.Employees.Find(empId);

            var employees = _context.Employees
                .Where(e => e.DepartmentId == manager.DepartmentId && e.Role == "Employee")
                .ToList();

            GeneratePayrollFor(employees, month, year);
            return RedirectToAction("ManagerDashboard");
        }

        [Authorize(Roles = "Manager")]
        public IActionResult TeamHistory()
        {
            var empId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier).Value);
            var manager = _context.Employees.Find(empId);

            var employees = _context.Employees
                .Where(e => e.DepartmentId == manager.DepartmentId && e.Role == "Employee")
                .OrderBy(e => e.EmpName)
                .ToList();

            return View(employees);
        }

        public IActionResult Details(int id, int? fromMonth, int? fromYear, int? toMonth, int? toYear)
        {
            var employee = _context.Employees.Include(e => e.Department).FirstOrDefault(e => e.Id == id);
            if (employee == null) return NotFound();

            // Access control
            if (User.IsInRole("Manager"))
            {
                var empId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier).Value);
                var manager = _context.Employees.Find(empId);
                if (employee.DepartmentId != manager.DepartmentId)
                {
                    return Forbid();
                }
            }
            else if (!User.IsInRole("Admin"))
            {
                return Forbid();
            }

            var query = _context.PayrollRecords.Where(p => p.EmployeeId == id);

            if (fromMonth.HasValue && fromYear.HasValue)
            {
                query = query.Where(p => (p.Year > fromYear.Value) || (p.Year == fromYear.Value && p.Month >= fromMonth.Value));
            }
            if (toMonth.HasValue && toYear.HasValue)
            {
                query = query.Where(p => (p.Year < toYear.Value) || (p.Year == toYear.Value && p.Month <= toMonth.Value));
            }

            var records = query.OrderByDescending(p => p.Year).ThenByDescending(p => p.Month).ToList();

            ViewBag.Employee = employee;
            ViewBag.FromMonth = fromMonth;
            ViewBag.FromYear = fromYear;
            ViewBag.ToMonth = toMonth;
            ViewBag.ToYear = toYear;
            ViewBag.BackAction = User.IsInRole("Admin") ? "AdminDashboard" : "TeamHistory";

            return View(records);
        }

        public IActionResult MyPayroll()
        {
            var empId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier).Value);

            var records = _context.PayrollRecords
                .Where(p => p.EmployeeId == empId)
                .OrderByDescending(p => p.Year).ThenByDescending(p => p.Month)
                .ToList();

            var currentSalary = _context.SalaryHistories
                .FirstOrDefault(s => s.EmployeeId == empId && s.EffectiveTo == null);

            var salaryHistory = _context.SalaryHistories
                .Where(s => s.EmployeeId == empId)
                .OrderByDescending(s => s.EffectiveFrom)
                .ToList();

            var today = DateTime.Today;
            var monthStart = new DateTime(today.Year, today.Month, 1);
            var monthEnd = monthStart.AddMonths(1).AddDays(-1);

            var thisMonthOvertime = _context.OvertimeRequests
                .Include(o => o.Attendance)
                .Where(o => o.EmployeeId == empId
                    && o.Status == OvertimeStatus.Approved
                    && o.Attendance.AttendanceDate >= monthStart
                    && o.Attendance.AttendanceDate <= monthEnd)
                .ToList();

            decimal totalHoursThisMonth = thisMonthOvertime.Sum(o => o.OvertimeHours);
            decimal extraPayThisMonth = currentSalary != null ? totalHoursThisMonth * currentSalary.OvertimeRatePerHour : 0;

            ViewBag.CurrentSalary = currentSalary;
            ViewBag.SalaryHistory = salaryHistory;
            ViewBag.TotalHoursThisMonth = totalHoursThisMonth;
            ViewBag.ExtraPayThisMonth = extraPayThisMonth;

            return View(records);
        }

        private void GeneratePayrollFor(List<Employee> employees, int month, int year)
        {
            var periodStart = new DateTime(year, month, 1);
            var periodEnd = periodStart.AddMonths(1).AddDays(-1);
            int totalDaysInMonth = DateTime.DaysInMonth(year, month);

            foreach (var emp in employees)
            {
                bool alreadyGenerated = _context.PayrollRecords
                    .Any(p => p.EmployeeId == emp.Id && p.Month == month && p.Year == year);

                if (alreadyGenerated) continue;

                // Agar employee is mahine ke baad join hua, skip karo (abhi tak exist hi nahi karta tha)
                if (emp.JoinDate > periodEnd) continue;

                var salary = _context.SalaryHistories
                    .Where(s => s.EmployeeId == emp.Id && s.EffectiveFrom <= periodEnd
                        && (s.EffectiveTo == null || s.EffectiveTo >= periodStart))
                    .OrderByDescending(s => s.EffectiveFrom)
                    .FirstOrDefault();

                if (salary == null) continue;

                // Proration: agar JoinDate isi mahine ke andar hai, to sirf join-date se mahine ke end tak ke din count honge
                var effectiveStart = emp.JoinDate > periodStart ? emp.JoinDate : periodStart;
                int daysWorked = (periodEnd - effectiveStart).Days + 1;

                decimal proratedBaseSalary = salary.BaseSalary;
                if (daysWorked < totalDaysInMonth)
                {
                    decimal perDayRate = salary.BaseSalary / totalDaysInMonth;
                    proratedBaseSalary = Math.Round(perDayRate * daysWorked, 2);
                }

                var approvedOvertime = _context.OvertimeRequests
                    .Include(o => o.Attendance)
                    .Where(o => o.EmployeeId == emp.Id
                        && o.Status == OvertimeStatus.Approved
                        && o.Attendance.AttendanceDate >= periodStart
                        && o.Attendance.AttendanceDate <= periodEnd)
                    .ToList();

                decimal totalOtHours = approvedOvertime.Sum(o => o.OvertimeHours);
                decimal otPay = totalOtHours * salary.OvertimeRatePerHour;

                _context.PayrollRecords.Add(new PayrollRecord
                {
                    EmployeeId = emp.Id,
                    Month = month,
                    Year = year,
                    BaseSalary = proratedBaseSalary,
                    TotalOvertimeHours = totalOtHours,
                    OvertimePay = otPay,
                    NetAmount = proratedBaseSalary + otPay,
                    GeneratedOn = DateTime.Now
                });
            }

            _context.SaveChanges();
        }
    }
}