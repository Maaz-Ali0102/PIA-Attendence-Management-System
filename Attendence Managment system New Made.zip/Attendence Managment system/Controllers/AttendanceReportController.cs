﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Attendence_Managment_system.Data;

namespace Attendence_Managment_system.Controllers
{
    [Authorize(Roles = "Admin")]
    public class AttendanceReportController : Controller
    {
        private readonly AppDbContext _context;

        public AttendanceReportController(AppDbContext context)
        {
            _context = context;
        }

        public IActionResult Index(int? departmentId, int? shiftId, DateTime? date)
        {
            var query = _context.Attendances
                .Include(a => a.Employee)
                    .ThenInclude(e => e.Department)
                .Include(a => a.Employee)
                    .ThenInclude(e => e.Shift)
                .AsQueryable();

            if (departmentId.HasValue)
            {
                query = query.Where(a => a.Employee.DepartmentId == departmentId.Value);
            }
            if (shiftId.HasValue)
            {
                query = query.Where(a => a.Employee.ShiftId == shiftId.Value);
            }
            if (date.HasValue)
            {
                query = query.Where(a => a.AttendanceDate == date.Value.Date);
            }

            var records = query.OrderByDescending(a => a.AttendanceDate)
                .ThenBy(a => a.Employee.EmpName)
                .Take(200)
                .ToList();

            ViewBag.Departments = _context.Departments.ToList();
            ViewBag.Shifts = _context.Shifts.ToList();
            ViewBag.SelectedDept = departmentId;
            ViewBag.SelectedShift = shiftId;
            ViewBag.SelectedDate = date;

            return View(records);
        }
    }
}