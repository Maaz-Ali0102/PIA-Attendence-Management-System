﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using Attendence_Managment_system.Data;
using Attendence_Managment_system.Models;

namespace Attendence_Managment_system.Controllers
{
    [Authorize(Roles = "Employee,Manager")]
    public class AttendanceController : Controller
    {
        private readonly AppDbContext _context;

        public AttendanceController(AppDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var empId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier).Value);
            var today = DateTime.Today;
            var now = DateTime.Now.TimeOfDay;

            var employee = _context.Employees.Find(empId);
            var shift = employee?.ShiftId != null ? _context.Shifts.Find(employee.ShiftId) : null;

            var todayRecord = _context.Attendances
                .FirstOrDefault(a => a.EmployeeId == empId && a.AttendanceDate == today);

            var history = _context.Attendances
                .Where(a => a.EmployeeId == empId)
                .OrderByDescending(a => a.AttendanceDate)
                .Take(10)
                .ToList();

            ViewBag.TodayRecord = todayRecord;

            if (shift != null)
            {
                ViewBag.CanMarkEntry = shift.IsWithinWindow(now);
            }
            else
            {
                ViewBag.CanMarkEntry = false;
                ViewBag.NoShiftAssigned = true;
            }

            return View(history);
        }

        [HttpPost]
        public IActionResult MarkAttendance()
        {
            var empId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier).Value);
            var today = DateTime.Today;
            var now = DateTime.Now;

            var employee = _context.Employees.Find(empId);
            if (employee == null || employee.ShiftId == null)
            {
                return RedirectToAction("Index");
            }

            var shift = _context.Shifts.Find(employee.ShiftId);
            if (shift == null)
            {
                return RedirectToAction("Index");
            }

            var record = _context.Attendances
                .FirstOrDefault(a => a.EmployeeId == empId && a.AttendanceDate == today);

            if (record == null || record.EntryTime == null)
            {
                if (!shift.IsWithinWindow(now.TimeOfDay))
                {
                    return RedirectToAction("Index");
                }

                var status = shift.IsLate(now.TimeOfDay) ? AttendanceStatus.Late : AttendanceStatus.InOffice;

                if (record == null)
                {
                    record = new Attendance
                    {
                        EmployeeId = empId,
                        AttendanceDate = today,
                        EntryTime = now,
                        Status = status
                    };
                    _context.Attendances.Add(record);
                }
                else
                {
                    record.EntryTime = now;
                    record.Status = status;
                }
            }
            else if (record.ExitTime == null)
            {
                record.ExitTime = now;

                if (record.Status == AttendanceStatus.InOffice)
                {
                    record.Status = AttendanceStatus.Present;
                }

                var shiftEnd = shift.GetShiftEndDateTime(record.AttendanceDate);
                var graceLimit = shiftEnd.AddMinutes(30);

                if (now > graceLimit)
                {
                    var overtimeHours = (decimal)(now - shiftEnd).TotalHours;

                    _context.OvertimeRequests.Add(new OvertimeRequest
                    {
                        AttendanceId = record.Id,
                        EmployeeId = empId,
                        OvertimeHours = Math.Round(overtimeHours, 2),
                        Status = OvertimeStatus.Pending,
                        CreatedDate = DateTime.Now
                    });
                }
            }

            _context.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}